#include<stdio.h>
int main(){
    int *a[5];
    for (int i = 0;i<5;++i){
        int b;
        a[i] = &b;
    }
    for (int i = 0;i <5;++i){
        *a[i] = i;
    } 

    for (int i = 0; i< 5;++i){
        printf("%d",*a[i]);
    }
}