
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                            global.c
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                                                    Forrest Yu, 2005
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#define GLOBAL_VARIABLES_HERE

#include "type.h"
#include "const.h"
#include "protect.h"
#include "tty.h"
#include "console.h"
#include "proc.h"
#include "global.h"
#include "proto.h"


PUBLIC	PROCESS	proc_table[NR_TASKS + NR_PROCS];

PUBLIC	TASK	task_table[NR_TASKS] = {
	{task_tty, STACK_SIZE_TTY, "tty"}};

PUBLIC  TASK    user_proc_table[NR_PROCS] = {
	{Producer_P1, STACK_SIZE_TESTA, "TestA"},
	{Producer_P2, STACK_SIZE_TESTB, "TestB"},
	{Consumer_C1, STACK_SIZE_TESTC, "TestC"},
	{Consumer_C2, STACK_SIZE_TESTD, "TESTD"},
	{Consumer_C3, STACK_SIZE_TESTE, "TESTE"},
	{ReporterForProAndCon, STACK_SIZE_TESTE, "TESTF"},
	};

PUBLIC	char		task_stack[STACK_SIZE_TOTAL];

PUBLIC	TTY		tty_table[NR_CONSOLES];
PUBLIC	CONSOLE		console_table[NR_CONSOLES];

PUBLIC	irq_handler	irq_table[NR_IRQ];

PUBLIC	system_call	sys_call_table[NR_SYS_CALL] = {sys_get_ticks,sys_sleep_ms,sys_disp_str,sys_semaphore_P,sys_semaphore_V};

PUBLIC int mode = INSERTMODE;  


unsigned int ESCBeginPos = 0;

int ESCInputLength = 0;

PUBLIC rwlock_t rwLock;
SEMAPHORE RepoLock = {1,0,0};
SEMAPHORE condToWakeProducer = {0,0,0};
SEMAPHORE condToWakeConsumer1= {0,0,0};
SEMAPHORE condToWakeConsumer23 = {0,0,0};

PUBLIC int Repo[N] = {0,0,0,0,0};

PUBLIC int P1 = 0;
PUBLIC int P2 = 0;
PUBLIC int C1 = 0;
PUBLIC int C2 = 0;
PUBLIC int C3 = 0;

PUBLIC int curGood1Num = 0;
PUBLIC int curGood2Num = 0;
