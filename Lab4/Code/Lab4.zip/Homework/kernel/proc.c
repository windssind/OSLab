
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
							   proc.c
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
													Forrest Yu, 2005
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#include "type.h"
#include "const.h"
#include "protect.h"
#include "tty.h"
#include "console.h"
#include "string.h"
#include "proc.h"
#include "global.h"
#include "proto.h"

/*======================================================================*
							  schedule
 *======================================================================*/
PUBLIC void schedule()
{
	PROCESS *p;
	int greatest_ticks = 0;
	/*只有currentTicks超过了wakticks，才可以调度*/
	while (!greatest_ticks)
	{
		for (p = proc_table; p < proc_table + NR_TASKS + NR_PROCS ; p++)
		{
			if (p->ticks > greatest_ticks && p->wake_tick <= get_ticks() && p->block == 0) // 只有不是睡眠状态并且不是阻塞状态才可以参与schedule
			{
				greatest_ticks = p->ticks;
				p_proc_ready = p; // 优先级越大，越早进入就绪态
			}
		}

		// 都没有找到，说明都执行完毕了或者有些被阻塞或者处于睡眠状态，重新将进程设定为优先级
		if (!greatest_ticks)
		{
			for (p = proc_table; p < proc_table + NR_TASKS + NR_PROCS; p++)
			{
				if (p->ticks > 0)
					continue; // 还有没有执行完的任务，说明阻塞了或者正在睡眠状态
				p->ticks = p->priority;
			}
		}
	}
}

/*
/* 如果还在wake，是不会进行调度的*/

/*只是以操作系统的内核态去运行这段代码罢了,不能在用户代码中直接调用这两个函数，用户调用的是get_ticks()和Mydisp_str*/
/*======================================================================*
						   sys_get_ticks
 *======================================================================*/
PUBLIC int sys_get_ticks()
{
	return ticks;
}

PUBLIC void sys_sleep_ms(int ms)
{
	p_proc_ready->wake_tick = ms * HZ *10 / 1000 + get_ticks(); // 将该进程弄成休眠（不同于阻塞）
	schedule();												// 重新调度其他线程
}

PUBLIC void sys_disp_str(char *ptr, int len)
{
	CONSOLE *p_con = console_table;
	for (int i = 0; i < len; i++)
	{
		out_char(p_con, ptr[i]);
	}
}

PUBLIC void sys_semaphore_P(SEMAPHORE *semaphore)
{
	disable_int(); // 关中断，在执行过程中不允许被中断
	semaphore->value--;
	if(semaphore->value < 0)
	{
		p_proc_ready->block = 1;						  // 当前进程处于阻塞状态
		semaphore->QUEUE[semaphore->tail] = p_proc_ready; // 加入等待队列，等待被唤醒
		semaphore->tail = (semaphore->tail + 1) % NR_PROCS;
		schedule(); // 重新调度其他的进程
	}
	enable_int(); // 开中断，此时允许被其他进程中断
}

PUBLIC void sys_semaphore_V(SEMAPHORE *semaphore) 
{
	disable_int(); // 关中断，在执行过程中不允许被中断
	semaphore->value++;
	if (semaphore->value <= 0)
	{
		semaphore->QUEUE[semaphore->head]->block = 0; // 被唤醒
		semaphore->head = (semaphore->head + 1) % NR_PROCS;
		// schedule(); // 有新的进程被唤醒，重新调度其他的进程,暂时并不需要，还是先走完当前的进程吧
	}
	enable_int(); // 开中断，此时允许被其他进程中断
}

/*======================================================================*
							  ReaderWriterLock
 *======================================================================*/

PUBLIC void rwlock_acquire_readlock(rwlock_t *rw)
{
	SEMAPHORE_P(&rw->lock);
	rw->readers++;
	if (rw->readers == 1) 
		SEMAPHORE_P(&rw->writelock); // first reader acquires writelock
	SEMAPHORE_V(&rw->lock);
}

PUBLIC void rwlock_release_readlock(rwlock_t *rw)
{
	SEMAPHORE_P(&rw->lock);
	rw->readers--;
	if (rw->readers == 0) 
		SEMAPHORE_V(&rw->writelock); // last reader releases writelock
	SEMAPHORE_V(&rw->lock);
}
PUBLIC void rwlock_acquire_writelock(rwlock_t *rw)
{
	SEMAPHORE_P(&rw->writelock);
}
PUBLIC void rwlock_release_writelock(rwlock_t *rw)
{
	SEMAPHORE_V(&rw->writelock);
}

int printf(const char *fmt, ...)
{
	int i;
	char buf[256];

	va_list arg = (va_list)((char*)(&fmt) + 4); /*4是参数fmt所占堆栈中的大小*/
	i = vsprintf(buf, fmt, arg);
	Mydisp_str(buf, i);
	return i;
}

int vsprintf(char *buf, const char *fmt, va_list args)
{
	char*	p;
	char	tmp[256];
	va_list	p_next_arg = args;

	for (p=buf;*fmt;fmt++) {
		if (*fmt != '%') {
			*p++ = *fmt;
			continue;
		}

		fmt++;

		switch (*fmt) {
		case 'd':
			itoa(tmp, *((int*)p_next_arg));

			strcpy(p, tmp);
			p_next_arg += 4;
			p += strlen(tmp);
			break;
		case 'c':
			*p = *p_next_arg;
			p_next_arg += 4;
			p++;
			break;
		case 's':
			break;
		default:
			break;
		}
	}
	return (p - buf);
}