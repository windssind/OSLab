
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
							main.c
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
													Forrest Yu, 2005
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#include "type.h"
#include "const.h"
#include "protect.h"
#include "string.h"
#include "proc.h"
#include "tty.h"
#include "console.h"
#include "global.h"
#include "proto.h"

/*======================================================================*
							kernel_main
 *======================================================================*/
PUBLIC int kernel_main()
{
	disp_str("-----\"kernel_main\" begins-----\n");

	TASK *p_task = task_table;
	PROCESS *p_proc = proc_table;
	char *p_task_stack = task_stack + STACK_SIZE_TOTAL;
	u16 selector_ldt = SELECTOR_LDT_FIRST;
	int i;
	u8 privilege;
	u8 rpl;
	int eflags;

	for (i = 0; i < NR_TASKS + NR_PROCS; i++)
	{
		if (i < NR_TASKS)
		{ /* 任务 */
			p_task = task_table + i;
			privilege = PRIVILEGE_TASK;
			rpl = RPL_TASK;
			eflags = 0x1202; /* IF=1, IOPL=1, bit 2 is always 1 */
		}
		else
		{ /* 用户进程 */
			p_task = user_proc_table + (i - NR_TASKS);
			privilege = PRIVILEGE_USER;
			rpl = RPL_USER;
			eflags = 0x202; /* IF=1, bit 2 is always 1 */
		}

		strcpy(p_proc->p_name, p_task->name); // name of the process
		p_proc->pid = i;					  // pid

		p_proc->ldt_sel = selector_ldt;

		/*将kernel的CS和DS的段描述符复制到用户进程的LDT中*/
		memcpy(&p_proc->ldts[0], &gdt[SELECTOR_KERNEL_CS >> 3],
			   sizeof(DESCRIPTOR));
		p_proc->ldts[0].attr1 = DA_C | privilege << 5;
		memcpy(&p_proc->ldts[1], &gdt[SELECTOR_KERNEL_DS >> 3],
			   sizeof(DESCRIPTOR));
		p_proc->ldts[1].attr1 = DA_DRW | privilege << 5;

		p_proc->regs.cs = (0 & SA_RPL_MASK & SA_TI_MASK) | SA_TIL | rpl;
		p_proc->regs.ds = (8 & SA_RPL_MASK & SA_TI_MASK) | SA_TIL | rpl;
		p_proc->regs.es = (8 & SA_RPL_MASK & SA_TI_MASK) | SA_TIL | rpl;
		p_proc->regs.fs = (8 & SA_RPL_MASK & SA_TI_MASK) | SA_TIL | rpl;
		p_proc->regs.ss = (8 & SA_RPL_MASK & SA_TI_MASK) | SA_TIL | rpl;
		p_proc->regs.gs = (SELECTOR_KERNEL_GS & SA_RPL_MASK) | rpl;

		p_proc->regs.eip = (u32)p_task->initial_eip;
		p_proc->regs.esp = (u32)p_task_stack;
		p_proc->regs.eflags = eflags;

		// 初始化全局的读写锁
		rwLock.readers = 0;
		rwLock.writers = 0;
		rwLock.lock.value = 1;
		rwLock.lock.head = 0;
		rwLock.lock.tail = 0;
		rwLock.writelock.value = 1;
		rwLock.writelock.head = 0;
		rwLock.writelock.tail = 0;
		rwLock.readCond.value = 0;
		rwLock.readCond.head = 0;
		rwLock.readCond.tail = 0;

		// 初始化wake_tick和初始状态
		p_proc->wake_tick = 0;
		p_proc->block = 0;

		p_task_stack -= p_task->stacksize;
		p_proc++;
		p_task++;
		selector_ldt += 1 << 3;
	}

	proc_table[0].ticks = proc_table[0].priority = 15;
	proc_table[1].ticks = proc_table[1].priority = 15;
	proc_table[2].ticks = proc_table[2].priority = 15;
	proc_table[3].ticks = proc_table[3].priority = 15;
	proc_table[4].ticks = proc_table[4].priority = 15;
	proc_table[5].ticks = proc_table[5].priority = 15;
	proc_table[6].ticks = proc_table[6].priority = 15;

	k_reenter = 0;
	ticks = 0;

	p_proc_ready = proc_table;

	init_clock();
	init_keyboard();
	restart();

	while (1)
	{
	}
}

/*======================================================================*
							   TestA
 *======================================================================*/
void TestA()
{
	while (1)
	{
		Mydisp_str("A", 1);
	}
}

/*======================================================================*
							   TestB
 *======================================================================*/
void TestB()
{
	int i = 0;
	while (1)
	{
		// milli_delay(100);
		// Mydisp_str("B",1);
	}
}

/*======================================================================*
							   TestC
 *======================================================================*/
void TestC()
{
	int i = 0x2000;
	while (1)
	{
		// disp_str("C.");
		// milli_delay(10);
		// Mydisp_str("C",1);
	}
}

/*======================================================================*
							   清屏,每隔20s左右清一次屏幕
 *======================================================================*/

void ClearScreen()
{
	disp_pos = 0;
	for (int i = 0; i < SCREEN_SIZE; ++i)
	{
		disp_str(" ");
	}
	disp_pos = 0;
}

void ReaderA()
{
	while (1)
	{
		Read_ReaderFirst(2);
		p_proc_ready->status = 0; // 休息中
		sleep_ms(TIMESLICE);
	}
}

void ReaderB()
{
	while (1)
	{
		Read_ReaderFirst(3);	  // 读十个时间片
		p_proc_ready->status = 0; // 休息中
		sleep_ms(TIMESLICE);	  // 休息一下
	}
}

void ReaderC()
{
	while (1)
	{
		Read_ReaderFirst(TIMESLICE);
		p_proc_ready->status = 0; // 休息中
		sleep_ms(10);
	}
}

void WriterA()
{
	while (1)
	{
		Write_ReaderFirst(3);
		p_proc_ready->status = 0; // 休息中
		sleep_ms(TIMESLICE);
	}
}

void WriterB()
{
	while (1)
	{
		Write_ReaderFirst(4);
		p_proc_ready->status = 0; // 休息中
		sleep_ms(TIMESLICE);
	}
}

void Report()
{
	int reportTimes = 0;
	while (1)
	{
		/*if (reportTimes < 20)
		{*/
		printf("\034%d: ", reportTimes);
		Print_Status(p_proc_ready);
		Mydisp_str("\n", 2);
		reportTimes++;
		sleep_ms(TIMESLICE); // 休息一个时间片
							 /*}*/
	}
}

void Producer_P1()
{
	while (1)
	{
		while (curGood1Num + curGood2Num >= N)
		{
			SEMAPHORE_P(&condToWakeProducer);
		}
		// 到了这一步，大概率是可以写的,但是由于我这个并不是真的条件变量，所以可能存在curGood1Num + curGood2Num又被修改的情况
		SEMAPHORE_P(&RepoLock);
		// 防止curGood1Num + curGood2Num又被修改了
		if (curGood1Num + curGood2Num >= N)
		{
			SEMAPHORE_V(&RepoLock);
			continue;
		}
		for (int i = 0; i < N; ++i)
		{
			if (Repo[i] == 0)
			{
				Repo[i] = 1;
				P1++;
				curGood1Num++;
				break;
			}
		}
		SEMAPHORE_V(&RepoLock);
		// 通知消费者起床
		SEMAPHORE_V(&condToWakeConsumer1);
		sleep_ms(TIMESLICE);
	}
}

void Producer_P2()
{
	while (1)
	{
		while (curGood1Num + curGood2Num >= N)
		{
			SEMAPHORE_P(&condToWakeProducer);
		}
		// 到了这一步，大概率是可以写的,但是由于我这个并不是真的条件变量，所以可能存在curGood1Num + curGood2Num又被修改的情况
		SEMAPHORE_P(&RepoLock);
		// 防止curGood1Num + curGood2Num又被修改了
		if (curGood1Num + curGood2Num >= N)
		{
			SEMAPHORE_V(&RepoLock);
			continue;
		}
		for (int i = 0; i < N; ++i)
		{
			if (Repo[i] == 0)
			{
				Repo[i] = 2;
				P2++;
				curGood2Num++;
				break;
			}
		}
		SEMAPHORE_V(&RepoLock);
		// 通知消费者起床，但是我通知了消费者起床，并不是立刻执行他，只不过是把他重新加入到调度的队列中。所以会出现5一直饿死的情况
		SEMAPHORE_V(&condToWakeConsumer23);
		sleep_ms(TIMESLICE);
	}
}

void Consumer_C1()
{
	while (1)
	{
		while (curGood1Num == 0)
		{
			SEMAPHORE_P(&condToWakeConsumer1);
		}

		SEMAPHORE_P(&RepoLock);
		// 防止curGood1Num + curGood2Num又被修改了
		if (curGood1Num == 0)
		{
			SEMAPHORE_V(&RepoLock);
			continue;
		}
		for (int i = 0; i < N; ++i)
		{
			if (Repo[i] == 1)
			{
				Repo[i] = 0;
				C1++;
				curGood1Num--;
				break;
			}
		}
		SEMAPHORE_V(&RepoLock);
		// 通知生产者起床（不能只通知只生产自己的货物的生产者，not fair）
		SEMAPHORE_V(&condToWakeProducer);
		sleep_ms(TIMESLICE);
	}
}

void Consumer_C2()
{
	while (1)
	{
		while (curGood2Num == 0)
		{
			SEMAPHORE_P(&condToWakeConsumer23);
		}

		SEMAPHORE_P(&RepoLock);
		// Mydisp_str("C2",2);
		//  防止curGood1Num + curGood2Num又被修改了
		if (curGood2Num == 0)
		{
			SEMAPHORE_V(&RepoLock);
			continue;
		}
		for (int i = 0; i < N; ++i)
		{
			if (Repo[i] == 2)
			{
				Repo[i] = 0;
				C2++;
				curGood2Num--;
				break;
			}
		}
		SEMAPHORE_V(&RepoLock);
		// 通知生产者起床（不能只通知只生产自己的货物的生产者，not fair）
		SEMAPHORE_V(&condToWakeProducer);
		sleep_ms(TIMESLICE);
	}
}

void Consumer_C3()
{
	while (1)
	{
		while (curGood2Num == 0)
		{
			SEMAPHORE_P(&condToWakeConsumer23);
		}

		SEMAPHORE_P(&RepoLock);
		// Mydisp_str("C3",2);
		//  防止curGood1Num + curGood2Num又被修改了
		if (curGood2Num == 0)
		{
			SEMAPHORE_V(&RepoLock);
			continue;
		}
		for (int i = 0; i < N; ++i)
		{
			if (Repo[i] == 2)
			{
				Repo[i] = 0;
				C3++;
				curGood2Num--;
				break;
			}
		}
		SEMAPHORE_V(&RepoLock);
		// 通知生产者起床（不能只通知只生产自己的货物的生产者，not fair）
		SEMAPHORE_V(&condToWakeProducer);
		sleep_ms(TIMESLICE);
	}
}

void ReporterForProAndCon()
{
	int reportTimes = 0;
	while (1)
	{
		if (reportTimes < 20)
		{
			printf("\034%d: ",reportTimes);

			Print_Status_ProAndCon();

			Mydisp_str("\n", 2);
			reportTimes++;
			sleep_ms(TIMESLICE); // 休息一个时间片
		}
	}
}

/*======================================================================*
							读写策略
 *======================================================================*/

// 读者优先策略 我认为这样并不能并发读(为什么需要一个全局的锁呢？因为reader++的原因，这个锁是用来维护reader的，reader此时也算一个临界资源了。是否这个lock直接放到reader++后面会好一点呢，只锁住reader。)
PUBLIC void Read_ReaderFirst(int timeSlice)
{
	// 开启读者锁并读
	SEMAPHORE_P(&(rwLock.lock));
	rwLock.readers++;
	if (rwLock.readers == 1)
		SEMAPHORE_P(&(rwLock.writelock)); // first reader acquires writelock，如果在这里阻塞的话，就说明有人在写
	SEMAPHORE_V(&(rwLock.lock));

	// 在读了，别吵
	p_proc_ready->status = 1; // 在运行
	sleep_ms(timeSlice * TIMESLICE);

	// 释放读者锁
	SEMAPHORE_P(&(rwLock.lock));
	rwLock.readers--;
	if (rwLock.readers == 0)
		SEMAPHORE_V(&(rwLock.writelock)); // first reader acquires writelock
	SEMAPHORE_V(&(rwLock.lock));
}

PUBLIC void Write_ReaderFirst(int timeSlice)
{
	// 获得写者锁
	SEMAPHORE_P(&(rwLock.writelock));

	// 写
	p_proc_ready->status = 1; // 在运行
	sleep_ms(timeSlice * TIMESLICE);

	// 释放写者锁
	SEMAPHORE_V(&(rwLock.writelock));
}

// 写者优先策略 只有所有的写者都结束了，才可以读

PUBLIC void Read_WriterFirst(int timeSlice)
{

	while (rwLock.writers > 0)
	{									 // 写成while总是好的，防止在被唤醒之后又被写者写了
		SEMAPHORE_P(&(rwLock.readCond)); // 等待被别人唤醒
	}

	// 在读了，别吵
	p_proc_ready->status = 1; // 在运行
	sleep_ms(timeSlice * TIMESLICE);
}

PUBLIC void Write_WriterFirst(int timeSlice)
{
	// 开启写者锁
	SEMAPHORE_P(&(rwLock.lock));
	rwLock.writers++; // lock主要是保证writer是临界区唯一的
	SEMAPHORE_V(&(rwLock.lock));

	// 在写了，别吵
	SEMAPHORE_P(&(rwLock.writelock)); // first writer acquires writelock，如果在这里阻塞的话，就说明有人在写
	p_proc_ready->status = 1;		  // 在运行
	sleep_ms(timeSlice * TIMESLICE);
	SEMAPHORE_V(&(rwLock.writelock)); // first reader acquires writelock

	// 释放写者锁
	SEMAPHORE_P(&(rwLock.lock));
	rwLock.writers--;
	SEMAPHORE_V(&(rwLock.lock));
	if (rwLock.writers == 0)
	{
		SEMAPHORE_V(&(rwLock.readCond)); // 在这里通知了，
	}
}

// 读写公平

PUBLIC void Read_Fair(int timeSlice)
{

	SEMAPHORE_P(&rwLock.writelock);

	// 在读了，别吵
	p_proc_ready->status = 1; // 在运行
	sleep_ms(timeSlice * TIMESLICE);

	SEMAPHORE_V(&(rwLock.writelock));
}

PUBLIC void Write_Fair(int timeSlice)
{
	// 开启写者锁
	SEMAPHORE_P(&(rwLock.writelock));

	p_proc_ready->status = 1; // 在运行
	sleep_ms(timeSlice * TIMESLICE);

	SEMAPHORE_V(&(rwLock.writelock));
}

PUBLIC void Print_Status(PROCESS *p)
{
	if (p->block)
	{
		Mydisp_str("\31X ", 4);
	}
	else if (p->status == 1)
	{ // 正在读或者写
		Mydisp_str("\32O ", 4);
	}
	else
	{
		Mydisp_str("\33Z ", 4);
	}
}

// 输出生产者和消费者的状态
PUBLIC void Print_Status_ProAndCon()
{
	printf("%d %d %d %d %d", P1, P2, C1, C2, C3);
}
